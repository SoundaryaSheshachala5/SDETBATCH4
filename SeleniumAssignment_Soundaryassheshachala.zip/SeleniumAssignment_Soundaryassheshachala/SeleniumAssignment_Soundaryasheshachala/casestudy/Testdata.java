package casestudy;

import java.util.ArrayList;
import java.util.HashMap;

public class Testdata {
	public static final String EXCEL_INPUT_FILE = "src/main/resources/TestData.xlsx";
	public static final String dataSheet="TestData1";
	public static final String CONFIG_PROP_FILE = "src/main/resources/TestConfig.properties";
	public static ArrayList<HashMap<String, String>> hmInput= new ArrayList<HashMap<String,String>>();
	public static ArrayList<HashMap<String, String>> listLocationTableDataUI= new ArrayList<HashMap<String,String>>();
	public static ArrayList<HashMap<String, String>> listGeneralInfoDataUI = new ArrayList<HashMap<String,String>>();

}
